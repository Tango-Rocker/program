# Project Setup Prompt: Milestone 0 Execution

Use this prompt after the bootstrap prompt when you want the coding agent to perform the concrete setup work for Milestone 0. It assumes the repository may be empty, partially bootstrapped, or already contains some files. The agent must inspect first, then make the smallest correct changes needed.

---

You are working in the repository for a large simulation-heavy top-down 2D hex-grid horde survival RTS/RPG.

The design doctrine is:

> The spreadsheet under the floor coughed.

The core fantasy is:

> The world hears you.

The project is intentionally large-scope. Do not shrink it into a tiny generic prototype. Instead, make the scope manageable through strong engineering: tickets, tests, docs, deterministic headless simulation, generated indexes, module boundaries, and session archives.

Your task is to complete Milestone 0: Project Skeleton and Agent Foundation.

Do not implement gameplay. Do not implement ECS, event bus, Lua, world rendering, horde AI, colony jobs, navigation, or UI beyond clearly documented stubs. Build the foundation that later agents will stand on.

---

## Required reading before editing

If these files exist, read them first:

```txt
AGENTS.md
docs/00_INDEX.md
docs/01_AGENT_DIRECTIVES.md
docs/02_ARCHITECTURE_MAP.md
docs/03_MODULE_MAP.md
docs/04_CODING_STANDARD.md
backlog/active.md
backlog/todo.md
```

If they do not exist, create them as part of this setup.

Inspect the current repository before making changes. Do not overwrite meaningful existing work without preserving or integrating it.

---

## Milestone 0 objective

Create a repository that can configure, build, test, and guide future agentic development.

The minimum outcome is:

```txt
CMake project
C17 configuration
optional SDL3 app target
headless test target
logging
assert macro
linear arena
seeded RNG
basic time utilities
fixed timestep skeleton
scripts for configure/build/test/format
AGENTS.md
docs 00 through 15
backlog files
seed tickets
session archive entry
README
```

---

## Build policy

The headless test target is mandatory.

The SDL app target is optional and must be controlled by:

```cmake
option(GAME_ENABLE_SDL "Build SDL app target" ON)
option(GAME_ENABLE_TESTS "Build tests" ON)
```

If SDL3 is unavailable, the project must still support:

```sh
cmake -S . -B build -DGAME_ENABLE_SDL=OFF -DGAME_ENABLE_TESTS=ON
cmake --build build
ctest --test-dir build --output-on-failure
```

Generate or enable `compile_commands.json`.

---

## Required repository structure

Create or verify:

```txt
src/core
src/platform
src/ecs
src/event
src/world
src/nav
src/sim
src/game
src/colony
src/lua
src/script
src/render
src/audio
src/ui
include/game
data/lua
schema
generated
docs
backlog/tickets
sessions
tests
tools/generators
tools/validators
tools/indexers
tools/agent_tools
scripts
```

Use `.gitkeep` for empty directories when needed.

---

## Required files and minimum implementation

Create or update:

```txt
CMakeLists.txt
README.md
AGENTS.md
.clang-format
.clang-tidy
.gitignore

src/core/log.h
src/core/log.c
src/core/asserts.h
src/core/arena.h
src/core/arena.c
src/core/random.h
src/core/random.c
src/core/time.h
src/core/time.c

src/platform/app.h
src/platform/app.c
src/platform/sdl_app.c
src/game/main.c

tests/test_main.c
tests/test_arena.c
tests/test_random.c

scripts/configure_debug.sh
scripts/build_debug.sh
scripts/test.sh
scripts/format.sh
```

### Logging

Implement levels:

```txt
TRACE DEBUG INFO WARN ERROR FATAL
```

The logging implementation can be simple. Include file/line helper macros if practical.

### Asserts

Add simple debug assertion macros. They should log useful context and abort in debug builds.

### Arena

Implement:

```c
typedef struct GameArena {
    unsigned char *base;
    size_t capacity;
    size_t offset;
} GameArena;

bool game_arena_init(GameArena *arena, size_t capacity);
void game_arena_destroy(GameArena *arena);
void *game_arena_push(GameArena *arena, size_t size, size_t alignment);
void game_arena_reset(GameArena *arena);
```

Tests must cover allocation, alignment, reset, and overflow returning `NULL`.

### RNG

Implement deterministic explicit-seed RNG:

```c
typedef struct GameRng {
    uint64_t state;
} GameRng;

void game_rng_seed(GameRng *rng, uint64_t seed);
uint32_t game_rng_u32(GameRng *rng);
float game_rng_float01(GameRng *rng);
```

Tests must prove same seed gives same sequence and float output is in `[0, 1)`.

### Time and fixed timestep

Provide a simple fixed timestep skeleton. The first app does not need gameplay. It can initialize, tick several times, log ticks, and shut down. If SDL is enabled and available, it may open a minimal window.

---

## Documentation files to create or verify

Create meaningful initial content for:

```txt
docs/00_INDEX.md
docs/01_AGENT_DIRECTIVES.md
docs/02_ARCHITECTURE_MAP.md
docs/03_MODULE_MAP.md
docs/04_CODING_STANDARD.md
docs/05_DATA_AND_LUA.md
docs/06_ECS_AND_EVENTS.md
docs/07_NAVIGATION.md
docs/08_UI_UX.md
docs/09_COLONY_JOBS.md
docs/10_HORDE_AI.md
docs/11_PROJECTILES_BUFFS_PARTICLES.md
docs/12_TESTING.md
docs/13_KNOWN_ISSUES.md
docs/14_SIMULATION_DOCTRINE.md
docs/15_AGENT_WORKFLOW.md
```

The docs must be usable by future agents. Avoid empty placeholder text.

They must preserve these rules:

```txt
UI emits intent.
Command system validates intent.
Simulation changes state.
Events report results.
UI reflects state.
```

```txt
The player is not owed omniscience.
The simulation is owed consistency.
The developer is owed traceability.
The agent is owed tests and indexes.
```

```txt
Commands are requests.
Events are facts.
Direct system scheduling handles deterministic core simulation.
Events carry cross-system consequences, UI/audio/debug reactions, delayed effects, and causal traces.
```

---

## Backlog files and seed tickets

Create or update:

```txt
backlog/active.md
backlog/todo.md
backlog/done.md
```

Create these ticket files if missing:

```txt
backlog/tickets/CORE-001-cmake-skeleton.md
backlog/tickets/CORE-002-fixed-timestep-loop.md
backlog/tickets/CORE-003-log-assert-arena-rng.md
backlog/tickets/TOOL-001-clangd-compile-commands.md
backlog/tickets/TOOL-002-build-format-test-scripts.md
backlog/tickets/DOC-001-agent-docs-index.md
backlog/tickets/ECS-001-entity-id-generation-storage.md
backlog/tickets/EVT-001-typed-event-bus-prototype.md
backlog/tickets/WORLD-001-axial-hex-coordinate-conversion.md
backlog/tickets/NAV-001-path-request-handle-api.md
backlog/tickets/NOISE-001-noise-emitted-event-and-field-impulse.md
backlog/tickets/HORDE-001-monster-hearing-and-noise-interest.md
backlog/tickets/COLONY-001-job-entity-and-job-board.md
```

Each ticket must include:

```md
# TICKET ID: Title

## Objective

## Context

## Acceptance criteria

## Allowed files

## Out of scope

## Required checks

## Notes
```

Do not mark tickets complete unless their acceptance criteria are actually satisfied.

---

## Session archive

Create a session archive entry:

```txt
sessions/YYYY-MM-DD/001-project-setup.md
```

Use the current date from the environment if possible.

The session archive must include:

```md
# Session: Project setup

## Goal

## Scope

## Files touched

## Decisions

## Known issues

## Tests run

## Next tasks
```

Be honest. If build or tests fail, include exact failure information.

---

## Required checks

At the end, run as many of these as available:

```sh
./scripts/configure_debug.sh
./scripts/build_debug.sh
./scripts/test.sh
```

If scripts are not executable, fix permissions or document how to run them.

Also try a direct headless configure if SDL is not installed:

```sh
cmake -S . -B build -DGAME_ENABLE_SDL=OFF -DGAME_ENABLE_TESTS=ON
cmake --build build
ctest --test-dir build --output-on-failure
```

If `clang-format` exists, run formatting on changed C/H files. If it does not exist, document that it was unavailable.

---

## Out of scope

Do not implement:

```txt
full ECS
event bus
Lua VM
hex world
pathfinding
noise fields
horde AI
colony jobs
UI widgets
rendering beyond optional minimal SDL window
save/load
replay harness
generated schema pipeline
```

Do not create elaborate fake versions of those systems. Create documentation and tickets for them.

---

## Final response format

When finished, respond with:

```md
## Summary

## Files created or changed

## Build/test results

## Failures or limitations

## Next recommended ticket
```

Do not claim success for checks that were not run.

Begin now.
